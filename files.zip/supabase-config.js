/* ============================================
   supabase-config.js — Credenciales del proyecto
   ============================================
   Rellena estos dos valores con los tuyos:
   Supabase Dashboard > Project Settings > API
   ============================================ */

const SUPABASE_URL = 'PEGA_AQUI_TU_PROJECT_URL';       // ej. https://xxxxx.supabase.co
const SUPABASE_ANON_KEY = 'PEGA_AQUI_TU_ANON_KEY';       // clave publica, es seguro exponerla

/* No tocar debajo de esta linea */
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
